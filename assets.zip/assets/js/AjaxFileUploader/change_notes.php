<?
	//Please contact me at cailongqun@yahoo.com.cn, if you need any website development.
	
	/**
	 * 12/April/2011
	 * enable to append extra data to be posted to the server along with the file
	 */
	
	/**
	 * 18/March/2011 Version 2.0
	 * upgraded to jquery 1.5.1
	 * fixed the bug on IE9. 
	 * 
	 */
	
	
	
	/**
	 * 25/Nov/2007 V1.0
	 * jquery 1.2.1 added
	 * minor change
	 * 
	 * 
	 * 
	 * 
	 * 21/May/2007 V0.5
	 * inital release
	 */
?>