<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Habitaciones_model extends CI_Model{
	public function lista_habitaciones(){
		$query = $this->db->query("SELECT h.id_habitacion,h.codigo,(select t.descripcion from tipo_habitacion t where t.id_tipo_hab = h.id_tipo_hab) as descripcion,(select t.costo from tipo_habitacion t where t.id_tipo_hab = h.id_tipo_hab) as costo, h.estado, IFNULL((select k.obs from kardex_hab k where k.id_hab = h.id_habitacion and k.vigente = 1),'') as obs FROM `habitaciones` h");
		return $query->result();
	}

	public function lista_tipos(){
		$query = $this->db->query("SELECT * from tipo_habitacion");
		return $query->result();
	}

	public function guarda_hab($datos){
		$datos = json_decode($datos);
		$query = $this->db->query("INSERT INTO habitaciones (codigo, id_tipo_hab, estado) values('$datos->cod_hab','$datos->tipo_hab','$datos->estado_hab')");
		return $query;
	}

	public function elimina_hab($datos){
		//$datos = json_decode($datos);
		$query = $this->db->query("DELETE FROM habitaciones where id_habitacion = '$datos'");
		return $query;
	}

	/***** Seccion para Tipos de Habitacón ******/
	public function lista_tipo_hab(){
		$query = $this->db->query("SELECT * FROM tipo_habitacion");
		return $query->result();
	}

	public function guarda_tipo_hab($datos){
		$datos = json_decode($datos);
		$query = $this->db->query("INSERT INTO tipo_habitacion (descripcion, personas,costo) values('$datos->desc_tipo_hab','$datos->num_personas','$datos->costo_hab')");

		return $this->db->insert_id();
	}

	public function edita_tipo_hab($datos){
		$datos = json_decode($datos);
		$query = $this->db->query("UPDATE tipo_habitacion SET descripcion = '$datos->tipo_desc', personas = '$datos->num_personas',costo = '$datos->costo' where id_tipo_hab = $datos->id_tipo");
		return $query;
	}
	
}
