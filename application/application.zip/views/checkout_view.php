<div class="input-group form-group">
  <span class="input-group-addon" id="basic-addon3">Check Out: </span>
  <input type="text" class="form-control" id="fecha_checkout" aria-describedby="basic-addon3" value="<?=date('d-m-Y H:i:s');?>">
</div>
<div class="input-group form-group">
  <span class="input-group-addon" id="basic-addon3"># Días hospedado: </span>
  <input type="text" class="form-control" id="dias_hosting" aria-describedby="basic-addon3">
</div>