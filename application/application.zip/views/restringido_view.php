<div style="text-align:center;">
	<img src="<?php echo base_url();?>assets/images/Not-Authorised.jpg" alt="">
	<p>
		<a href="login">Login</a>
	</p>
</div>