<div class="input-group form-group">
  <span class="input-group-addon" id="basic-addon3">Check In: </span>
  <input type="text" class="form-control" id="fecha_checkin" aria-describedby="basic-addon3" value="<?=date('d-m-Y H:i:s');?>">
</div>
<!-- <div class="input-group form-group">
  <span class="input-group-addon" id="basic-addon3">Check Out: </span>
  <input type="text" class="form-control" id="fecha_checkout" aria-describedby="basic-addon3">
</div> -->
<div class="input-group form-group">
  <span class="input-group-addon" id="basic-addon3">CI/Pasaporte: </span>
  <input type="text" class="form-control" id="ci_passport" aria-describedby="basic-addon3">
</div>
<div class="input-group form-group">
  <span class="input-group-addon" id="basic-addon3">Nombre y Apellidos: </span>
  <input type="text" class="form-control" id="nombre_apell" aria-describedby="basic-addon3">
</div>
<div class="input-group form-group">
  <span class="input-group-addon" id="basic-addon3">Habitación: </span>
  <input type="text" class="form-control" id="id_habitacion" aria-describedby="basic-addon3">
</div>
<div class="input-group form-group">
  <span class="input-group-addon" id="basic-addon3">Nro. Personas: </span>
  <input type="text" class="form-control" id="num_personas" aria-describedby="basic-addon3">
</div>
<div class="input-group form-group">
  <span class="input-group-addon" id="basic-addon3">Tarifa: </span>
  <input type="text" class="form-control" id="tarifa_hab" aria-describedby="basic-addon3">
</div>
<div class="input-group form-group">
  <span class="input-group-addon" id="basic-addon3">Adelanto: </span>
  <input type="text" class="form-control" id="adelanto" aria-describedby="basic-addon3">
</div>
<div class="input-group form-group">
  <span class="input-group-addon" id="basic-addon3">Observaciones: </span>
  <input type="text" class="form-control" id="observaciones" aria-describedby="basic-addon3">
</div>