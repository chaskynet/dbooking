<!-- *** Modal para Nueva Habitación *** -->
<div class="modal fade" id="modal_nueva_habitacion" tabindex="-1" role="dialog" aria-labelledby="modal_nueva_habitacion">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Nueva Habitación</h4>
      </div>
      <div class="modal-body">
        <div class="input-group">
		  <span class="input-group-addon" id="basic-addon3">Codigo: </span>
		  <input type="text" class="form-control" id="basic-url" aria-describedby="basic-addon3">
		</div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
        <button type="button" class="btn btn-primary">Guardar Habitación</button>
      </div>
    </div>
  </div>
</div>
<!-- *** FIN venta modal para Nueva Habitación *** -->
<!-- *** Modal para Tipo Habitación *** -->
<div class="modal fade" id="modal_tipo_habitacion" tabindex="-1" role="dialog" aria-labelledby="modal_tipo_habitacion">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Nuevo Tipo de Habitación</h4>
      </div>
      <div class="modal-body">
        <div class="input-group">
		  <span class="input-group-addon" id="basic-addon3">Descripción: </span>
		  <input type="text" class="form-control" id="desc_tipo_hab" aria-describedby="basic-addon3">
		</div>
		<div class="input-group">
		  <span class="input-group-addon" id="basic-addon3"># de Personas: </span>
		  <input type="text" class="form-control" id="num_personas" aria-describedby="basic-addon3">
		</div>
		<div class="input-group">
		  <span class="input-group-addon" id="basic-addon3">Costo: </span>
		  <input type="text" class="form-control" id="costo_hab" aria-describedby="basic-addon3">
		</div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
        <button type="button" id="guarda_tipo" class="btn btn-primary">Guardar Tipo de Habitación</button>
      </div>
    </div>
  </div>
</div>
<!-- *** FIN venta modal para Tipo Habitación *** -->

<!-- *** Panel para Gestión de Habitación *** -->
<!-- Botones de acceso a las diferentes areas de la gestion de Habitaciones -->
<button class="btn btn-primary" type="button" data-toggle="collapse" data-target="#gestion_habitaciones" aria-expanded="false" aria-controls="gestion_habitaciones">
  Gestión de Habitaciones
</button>
<button class="btn btn-primary" type="button" data-toggle="collapse" data-target="#tipo_habitaciones" aria-expanded="false" aria-controls="tipo_habitaciones">
  Tipo de Habitaciones
</button>
<!-- Seccion contenido de los paneles desplegables -->
<div class="collapse" id="gestion_habitaciones">
  <div class="well">
	<div class="row">
		<h3 style='padding-top:0px;margin-top:0px;'>Gestión de Habitaciones</h3>
		<button class="btn btn-danger" id="agregar-articulos" data-toggle="modal" data-target="#modal_nueva_habitacion"><span class="glyphicon glyphicon-plus"></span> Nueva Habitación</button>
		
		<table class="table table-bordered table-striped table-hover table-condensed">
			<tr>
				<th>#</th>
				<th>Codigo</th>
				<th>Descripción</th>
				<th>Tipo</th>
				<th>Costo</th>
				<th>Estado</th>
			</tr>
			<?php
				$i = 0;
				foreach ($habitaciones as $key) {
					$i++;
			?>
			<tr id="<?= $key->id_usuario; ?>">
				<td><?= $i; ?>&nbsp; <a href="#" id="elimina_usr"><span class="glyphicon glyphicon-trash"></span></a></td>

				<td><?= $key->uname; ?></td>
				<td><a href="#" data-toggle="modal" data-target="#modal_edita_usuario" id="nombre_usuario"><?= $key->nombre.' '.$key->apaterno.' '.$key->amaterno; ?></a></td>
				<td class="centrar"><?= $key->ci; ?></td>
				<td class="centrar"><?= $key->estado ? 'Activo' : 'Desactivado'; ?></td>
				<!-- <td class="centrar"><?= $key->rol ? 'Usuario' : 'Administrador'; ?></td> -->
			</tr>
			<?php
				}
			?>
		</table>
	</div>
  </div>
</div>
<!-- ******* -->

<!-- *** Panel para Tipo de Habitación *** -->

<div class="collapse" id="tipo_habitaciones">
  <div class="well">
	<div class="row">
		<h3 style='padding-top:0px;margin-top:0px;'>Tipo de Habitaciones</h3>
		<button class="btn btn-danger" id="agregar-articulos" data-toggle="modal" data-target="#modal_tipo_habitacion"><span class="glyphicon glyphicon-plus"></span> Nuevo Tipo </button>
		
		<table class="table table-bordered table-striped table-hover table-condensed">
			<tr>
				<th>#</th>
				<th>Descripción</th>
				<th>Nro. Personas</th>
				<th>Costo</th>
			</tr>
			<?php
				$i = 0;
				foreach ($tipo as $key) {
					$i++;
			?>
			<tr>
				<td><?=$i;?></td>
			</tr>
			<?php
				}
			?>
		</table>
	</div>
  </div>
</div>
<!-- ******* -->
