<div class="row-fluid">

	<div class="panel panel-primary panel_caja" data-container="body" data-toggle="popover" title="Kardex de la Caja" data-content="La Caja esta lista la Apertura!!">
		<div class="panel-heading">
			Apertura de Caja
			<button class="btn btn-info">Abrir</button>
		</div>

			<div class="panel-body">
			   <table class="table">
			   		<tr>
			   			<th>Estado</th>
			   			<td>Cerrado</td>
			   		</tr>
			   		<tr>
			   			<th>Fecha</th>
			   			<td><?=date('d/m/Y');?></td>
			   		</tr>
			   		<tr>
			   			<th>Saldo Inicial</th>
			   			<td>1000 Bs.</td>
			   		</tr>
			   		<tr>
			   			<th>Saldo de cierre</th>
			   			<td>20000 Bs.</td>
			   		</tr>
			   </table>
			</div>
	</div>
	
</div>